//
//  ViewController.swift
//  Hamburguesas
//
//  Created by Alejandro Rico Espinosa on 6/14/19.
//  Copyright © 2019 Alejandro Rico Espinosa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //Constantes
    let pais = ColeccionDePaises()
    let hamburguesa = ColeccionDeHamburguesa()
    
    @IBOutlet weak var paisEtiqueta: UILabel!
    
    @IBOutlet weak var hamburguesaEtiqueta: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func quererHamburguesa() {
        
        paisEtiqueta.text = pais.obtenPais()
        hamburguesaEtiqueta.text = hamburguesa.obtenHamburguesa()
        
    }
    
}

