//
//  Datos.swift
//  Hamburguesas
//
//  Created by Alejandro Rico Espinosa on 6/14/19.
//  Copyright © 2019 Alejandro Rico Espinosa. All rights reserved.
//

import Foundation
import UIKit

class ColeccionDePaises{
    let paises = ["Argentina","Brasil","Colombia","Panama","Chile","Ecuador","Peru","Venezuela","Bolivia","Mexico","Estados Unidos","Canada","Costa Rica","Alemania","Holanda","Italia","España","Francia","Uruguay","Paraguay"]
    
    func obtenPais( )->String{
        let posicion = Int (arc4random()) % paises.count
        return paises[posicion]
    }
}

class ColeccionDeHamburguesa{
    let hamburguesas = ["Hamburguesa Con Queso","Hamburguesa Clasica De Ternera","Hamburguesa Clasica de Puerco","Hamburguesa De Jamon Serrano y Piña","Hamburguesa de Pollo Apanado","Hamburguesa Con Chorizo","Hamburguesa De Salmon","Hamburguesa Clasica","Hamburguesa Doble Carne","Hamburguesa de Atun","Hamburguesa Mexicana","Hamburguesa Cuarto de Libra","Hamburguesa Americana","Hamburguesa Todoterreno","Hamburguesa con Champiñones","Hamburguesa Con Todos Los Quesos","Hamburguesa Al Carbon","Hamburguesa Con Lechuga y Tomate","Hamburguesa En Pan Arabe","Hamburguesa Clasica de Bufalo"]
    
    func obtenHamburguesa( )->String{
        let posicion = Int (arc4random()) % hamburguesas.count
        return hamburguesas[posicion]
    }
}
